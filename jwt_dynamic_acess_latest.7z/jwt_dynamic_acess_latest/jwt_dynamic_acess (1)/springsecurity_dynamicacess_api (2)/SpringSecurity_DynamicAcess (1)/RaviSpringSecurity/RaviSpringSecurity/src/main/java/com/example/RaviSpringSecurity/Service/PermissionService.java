package com.example.RaviSpringSecurity.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.AntPathMatcher;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class PermissionService implements PermissionServiceInterface {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;  // Inject RedisTemplate for caching

    @Autowired
    private ObjectMapper objectMapper;  // Inject ObjectMapper for JSON serialization

    private final AntPathMatcher pathMatcher = new AntPathMatcher();

    private static final String PERMISSIONS_CACHE_KEY_PREFIX = "permissions:";

    private final Map<String, List<Permission>> localCache = new ConcurrentHashMap<>();



    public boolean hasPermission(String role, String requestUri, String httpMethod) {
        if (role == null || requestUri == null || httpMethod == null) return false;

        List<Permission> permissions = localCache.get(role);  // Step 1: Try local cache

        if (permissions == null) {
            permissions = getPermissionsFromCache(role);  // Step 2: Try Redis cache

            if (permissions == null) {
                permissions = fetchPermissionsFromDb(role);  // Step 3: Fallback to DB
                updatePermissionsCache(role, permissions);   // Update Redis
            }

            localCache.put(role, permissions);  // Step 4: Update local cache
        }

        for (Permission perm : permissions) {
            if (pathMatcher.match(perm.apiPattern, requestUri)
                    && (perm.httpMethod.equals("*") || perm.httpMethod.equalsIgnoreCase(httpMethod))) {
                return true;
            }
        }
        return false;
    }


    private List<Permission> getPermissionsFromCache(String role) {
        String cacheKey = PERMISSIONS_CACHE_KEY_PREFIX + role;

        // Fetch permissions from Redis cache (if available)
        String permissionsJson = redisTemplate.opsForValue().get(cacheKey);
        if (permissionsJson != null) {
            try {
                return objectMapper.readValue(permissionsJson, new TypeReference<List<Permission>>() {});
            } catch (IOException e) {
                // If there was an error deserializing, log and return null
                e.printStackTrace();
            }
        }
        return null;
    }

    private static final String PERMISSIONS_CHANNEL = "permissions-invalidation";

    private void updatePermissionsCache(String role, List<Permission> permissions) {
        String cacheKey = PERMISSIONS_CACHE_KEY_PREFIX + role;
        try {
            String permissionsJson = objectMapper.writeValueAsString(permissions);
            redisTemplate.opsForValue().set(cacheKey, permissionsJson);

            // Invalidate local cache across pods
            redisTemplate.convertAndSend(PERMISSIONS_CHANNEL, role);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private List<Permission> fetchPermissionsFromDb(String role) {
        String sql = "SELECT api_pattern, http_method FROM role_permissions WHERE role = ?";

        return jdbcTemplate.query(sql, (rs, rowNum) -> new Permission(
                rs.getString("api_pattern"),
                rs.getString("http_method")
        ), role);
    }

    public void invalidateLocalCache(String role) {
        localCache.remove(role); // Clear first
        List<Permission> updated = getPermissionsFromCache(role); // Redis fetch
        if (updated != null) {
            localCache.put(role, updated); // Refill local cache immediately
        }
    }

    public void clearCacheForRole(String role) {
        String cacheKey = PERMISSIONS_CACHE_KEY_PREFIX + role;
        redisTemplate.delete(cacheKey);  // Remove permissions from Redis cache for the given role
    }

    private static class Permission {
        String apiPattern;
        String httpMethod;

        public Permission() {}

        public Permission(String apiPattern, String httpMethod) {
            this.apiPattern = apiPattern;
            this.httpMethod = httpMethod;
        }

        public String getApiPattern() {
            return apiPattern;
        }

        public String getHttpMethod() {
            return httpMethod;
        }
    }
}

