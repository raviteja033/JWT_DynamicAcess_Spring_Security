package com.example.RaviSpringSecurity.Service;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;
import java.util.Date;

@Component
public class JwtUtil implements JwtUtilInterface {

    // JWT secret key (for signing)
    private final String SECRET_KEY = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"; // 64 chars

    // AES secret key (must be 16 chars = 128 bit)
    private final String AES_KEY = "1234567812345678";

    private final long EXPIRATION_TIME = 1000 * 60 * 60; // 1 hour

    private final Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes());

    // 🔐 Generate JWT & then encrypt it using AES
    public String generateToken(String username) {
        String jwt = Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();

        try {
            return encrypt(jwt);
        } catch (Exception e) {
            throw new RuntimeException("Error while encrypting JWT", e);
        }
    }

    // 🔓 Decrypt the token, then extract username
    public String extractUsername(String encryptedToken) {
        try {
            String decryptedToken = decrypt(encryptedToken);
            return Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(decryptedToken)
                    .getBody()
                    .getSubject();
        } catch (Exception e) {
            throw new RuntimeException("Invalid or corrupted token", e);
        }
    }

    // ✅ Decrypt and validate JWT
    public boolean validateToken(String encryptedToken) {
        try {
            String decryptedToken = decrypt(encryptedToken);
            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(decryptedToken);
            return true;
        } catch (JwtException e) {
            return false;
        } catch (IllegalArgumentException e) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // AES Encrypt
    private String encrypt(String plainText) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());

        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    // AES Decrypt
    private String decrypt(String encryptedText) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedText));

        return new String(decryptedBytes);
    }
}

