package com.example.RaviSpringSecurity.controller;

import com.example.RaviSpringSecurity.pojo.url;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api")
public class UrlController {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/getallurls")
    public ResponseEntity<List<url>> getAllUrls() {
        String sql = "SELECT * FROM url_master";

        // fetching all urls
        List<url> urls = jdbcTemplate.query(sql, (rs, rowNum) ->
                new url(
                        rs.getInt("id"),
                        rs.getString("method"),
                        rs.getString("http_pattern"),
                        rs.getString("significance") // assuming there's a column called 'description'
                        // Add more fields as needed, based on your table structure
                )
        );

        // Returning all URLs in the response
        return ResponseEntity.ok(urls);
    }



}
