package com.example.RaviSpringSecurity.pojo;


import java.util.List;

public class RolePermissionUpdateRequest {
    private String role;
    private List<PermissionDTO> permissions;

    public RolePermissionUpdateRequest() {
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<PermissionDTO> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<PermissionDTO> permissions) {
        this.permissions = permissions;
    }
}
