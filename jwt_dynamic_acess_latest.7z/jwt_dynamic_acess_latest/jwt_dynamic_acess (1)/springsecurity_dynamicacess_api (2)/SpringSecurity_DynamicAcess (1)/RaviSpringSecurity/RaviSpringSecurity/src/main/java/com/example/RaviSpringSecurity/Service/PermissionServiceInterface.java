package com.example.RaviSpringSecurity.Service;

import java.util.List;

public interface PermissionServiceInterface {

    public void clearCacheForRole(String role);
    public boolean hasPermission(String role, String requestUri, String httpMethod);


}
