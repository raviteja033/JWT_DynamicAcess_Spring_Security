package com.example.RaviSpringSecurity.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Service;

@Service
public class PermissionCacheInvalidationListener implements MessageListener {

    @Autowired
    private PermissionService permissionService;

    @Override
    public void onMessage(Message message, byte[] pattern) {
        String role = new String(message.getBody());
        permissionService.invalidateLocalCache(role);

    }
}



