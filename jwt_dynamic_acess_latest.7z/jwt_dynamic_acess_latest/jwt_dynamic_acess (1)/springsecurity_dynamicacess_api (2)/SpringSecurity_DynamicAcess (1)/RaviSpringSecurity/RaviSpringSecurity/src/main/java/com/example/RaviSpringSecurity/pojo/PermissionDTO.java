package com.example.RaviSpringSecurity.pojo;


public class PermissionDTO {
    private String apiPattern;
    private String httpMethod;
    private String type;

    public PermissionDTO() {
    }

    public PermissionDTO(String apiPattern, String httpMethod) {
        this.apiPattern = apiPattern;
        this.httpMethod = httpMethod;
    }

    public String getApiPattern() {
        return apiPattern;
    }

    public void setApiPattern(String apiPattern) {
        this.apiPattern = apiPattern;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

