package com.example.RaviSpringSecurity.pojo;

public class url {
    private int  id;
    private String method;
    private String http_pattern;
    private String Significance;

    public url() {

    }

    public url(int id, String method, String http_pattern, String significance) {
        this.id = id;
        this.method = method;
        this.http_pattern = http_pattern;
        Significance = significance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getHttp_pattern() {
        return http_pattern;
    }

    public void setHttp_pattern(String http_pattern) {
        this.http_pattern = http_pattern;
    }

    public String getSignificance() {
        return Significance;
    }

    public void setSignificance(String significance) {
        Significance = significance;
    }
}
