package com.example.RaviSpringSecurity.Service;

import com.example.RaviSpringSecurity.pojo.Employee;

import java.util.List;

public interface EmployeeServiceInterface {

    public List<Employee> getAll();

    public Employee getById(int id);

    public void add(Employee emp);

    public void update(Employee emp);

    public void delete(int id);


}
