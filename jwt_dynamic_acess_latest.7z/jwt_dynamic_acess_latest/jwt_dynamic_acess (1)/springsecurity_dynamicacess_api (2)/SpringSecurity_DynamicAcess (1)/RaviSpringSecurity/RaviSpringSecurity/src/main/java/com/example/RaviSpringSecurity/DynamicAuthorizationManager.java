package com.example.RaviSpringSecurity;

import com.example.RaviSpringSecurity.Service.JwtUtil;
import com.example.RaviSpringSecurity.Service.PermissionService;
import com.example.RaviSpringSecurity.Service.PermissionServiceInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Collection;
import java.util.function.Supplier;

@Component
public class DynamicAuthorizationManager implements AuthorizationManager<HttpServletRequest> {

    @Autowired
    private PermissionServiceInterface permissionService;
    @Autowired
    private JwtUtil jwtUtil;               // Inject JwtUtil here
    @Autowired
    private DataSource dataSource;         // Inject DataSource here


    @Override
    public AuthorizationDecision check(Supplier<Authentication> authentication, HttpServletRequest request) {
        Authentication auth = authentication.get();

        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return new AuthorizationDecision(false);
        }

        String uri = request.getRequestURI().replaceAll("/+$", ""); // Normalize trailing slash removing the slashes at the end of the string
        String method = request.getMethod();//   Get the HTTP method of the request (e.g., GET, POST, PUT, DELETE)

        Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();

        boolean allowed = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(role -> permissionService.hasPermission(role, uri, method));

        return new AuthorizationDecision(allowed);
    }
    @Bean
    public JdbcUserDetailsManager userDetailsService() {
        return new JdbcUserDetailsManager(dataSource);
    }

    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        // Pass dependencies to JwtAuthenticationFilter constructor
        return new JwtAuthenticationFilter(jwtUtil, userDetailsService());
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/api/**").access(DynamicAuthorizationManager1())
                        .anyRequest().permitAll()
                )
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthorizationManager<RequestAuthorizationContext> DynamicAuthorizationManager1() {
        return (authentication, context) -> {
            HttpServletRequest request = context.getRequest();
            Authentication auth = authentication.get();

            if (auth == null || !auth.isAuthenticated()) {
                return new AuthorizationDecision(false);
            }

            String uri = request.getRequestURI().replaceAll("/+$", "");
            String method = request.getMethod();

            Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();

            boolean allowed = authorities.stream()
                    .map(GrantedAuthority::getAuthority)
                    .anyMatch(role -> permissionService.hasPermission(role, uri, method));

            return new AuthorizationDecision(allowed);
        };
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}


