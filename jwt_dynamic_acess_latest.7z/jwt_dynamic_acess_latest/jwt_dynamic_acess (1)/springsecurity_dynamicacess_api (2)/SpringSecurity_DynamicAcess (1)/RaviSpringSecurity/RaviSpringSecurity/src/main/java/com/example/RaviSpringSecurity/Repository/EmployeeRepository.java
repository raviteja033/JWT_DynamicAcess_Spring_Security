package com.example.RaviSpringSecurity.Repository;



import com.example.RaviSpringSecurity.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Employee> findAll() {
        return jdbcTemplate.query("SELECT * FROM employees",
                (rs, rowNum) -> new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("position")));
    }

    public Employee findById(int id) {
        return jdbcTemplate.queryForObject("SELECT * FROM employees WHERE id = ?",
                new Object[]{id},
                (rs, rowNum) -> new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("position")));
    }

    public int save(Employee employee) {
        return jdbcTemplate.update("INSERT INTO employees (name, position) VALUES (?, ?)",
                employee.getName(), employee.getPosition());
    }

    public int update(Employee employee) {
        return jdbcTemplate.update("UPDATE employees SET name = ?, position = ? WHERE id = ?",
                employee.getName(), employee.getPosition(), employee.getId());
    }

    public int deleteById(int id) {
        return jdbcTemplate.update("DELETE FROM employees WHERE id = ?", id);
    }
}
