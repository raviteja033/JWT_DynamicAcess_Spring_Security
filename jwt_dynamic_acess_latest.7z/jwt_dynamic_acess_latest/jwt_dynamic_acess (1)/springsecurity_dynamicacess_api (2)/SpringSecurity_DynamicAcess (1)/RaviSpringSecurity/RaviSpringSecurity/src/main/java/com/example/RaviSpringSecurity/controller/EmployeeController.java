package com.example.RaviSpringSecurity.controller;

import com.example.RaviSpringSecurity.pojo.Employee;
import com.example.RaviSpringSecurity.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @GetMapping
    public List<Employee> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Employee getById(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public String create(@RequestBody Employee emp) {
        service.add(emp);
        return "Created";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable int id, @RequestBody Employee emp) {
        emp.setId(id);
        service.update(emp);
        return "Updated";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable int id) {
        service.delete(id);
        return "Deleted";
    }
}
