package com.example.RaviSpringSecurity.Service;


import com.example.RaviSpringSecurity.pojo.Employee;
import com.example.RaviSpringSecurity.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService implements EmployeeServiceInterface {

    @Autowired
    private EmployeeRepository repository;

    public List<Employee> getAll() {
        return repository.findAll();
    }

    public Employee getById(int id) {
        return repository.findById(id);
    }

    public void add(Employee emp) {
        repository.save(emp);
    }

    public void update(Employee emp) {
        repository.update(emp);
    }

    public void delete(int id) {
        repository.deleteById(id);
    }
}
