package com.example.RaviSpringSecurity.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor  // Needed for JSON deserialization
public class AuthRequest {
    private String username;
    private String password;
}
