package com.example.RaviSpringSecurity.PasswordGenerator;

public class PasswordGenerator2 {
    public static void main(String[] args) {
        System.out.println(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode("manager123"));
    }
}
