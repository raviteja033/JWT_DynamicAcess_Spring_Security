package com.example.RaviSpringSecurity.pojo;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({ "role", "method", "url" })
public class ApiListDTO {
    private String role;  // Lowercase field name for consistency
    private String method;
    private String url;
}
