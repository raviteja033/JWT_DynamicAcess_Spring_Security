package com.example.RaviSpringSecurity.Service;

public interface JwtUtilInterface {

    public String generateToken(String username);
    public String extractUsername(String token);
    public boolean validateToken(String token);
}
