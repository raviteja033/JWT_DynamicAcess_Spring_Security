package com.example.RaviSpringSecurity.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // generates constructor with all args (including token)
@NoArgsConstructor   // generates no-arg constructor (optional but good practice)
public class AuthResponse {
    private String token;
}
