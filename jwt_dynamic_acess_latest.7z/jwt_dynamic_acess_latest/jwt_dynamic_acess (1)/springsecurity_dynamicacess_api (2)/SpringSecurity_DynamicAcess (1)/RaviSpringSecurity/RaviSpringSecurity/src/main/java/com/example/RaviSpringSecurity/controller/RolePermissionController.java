package com.example.RaviSpringSecurity.controller;

import com.example.RaviSpringSecurity.pojo.*;
import com.example.RaviSpringSecurity.Service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.security.Permission;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/roles")
public class RolePermissionController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private PermissionService permissionService;

    @PostMapping("/update")
    public String updateRolePermissions(@RequestBody RolePermissionUpdateRequest request) {
        permissionService.invalidateLocalCache("ROLE_MANAGER");
        if (request == null || request.getRole() == null || request.getPermissions() == null) {
            return "Invalid input. Role and permissions must be provided.";
        }

        // process each one through loop
        for (PermissionDTO perm : request.getPermissions()) {
            if (perm.getType() == null || perm.getApiPattern() == null || perm.getHttpMethod() == null) {
                return "Invalid permission data. 'type', 'apiPattern', and 'httpMethod' are required.";
            }

            //  if type is "remove"
            if ("remove".equalsIgnoreCase(perm.getType())) {
                jdbcTemplate.update(
                        "DELETE FROM role_permissions WHERE role = ? AND api_pattern = ? AND http_method = ?",
                        request.getRole(), perm.getApiPattern(), perm.getHttpMethod()
                );
            }
            //  if type is "add"
            else if ("add".equalsIgnoreCase(perm.getType())) {
                jdbcTemplate.update(
                        "INSERT INTO role_permissions (role, api_pattern, http_method) VALUES (?, ?, ?)",
                        request.getRole(), perm.getApiPattern(), perm.getHttpMethod()
                );
            } else {
                return "Invalid permission type: " + perm.getType();
            }
        }

        // Invalidate the local cache after updating permissions
        permissionService.invalidateLocalCache(request.getRole());
        // invalidate the redis cache after updating permissions
        permissionService.clearCacheForRole(request.getRole());


        return "Permissions successfully updated for role: " + request.getRole();

    }


// get roles and their methods and urls
 @GetMapping("/getAllPermissionsByRole")
 public ResponseEntity<Map<String, List<ApiListDTO>>> getAllPermissionsByRole() {
    String sql = "SELECT role, http_method, api_pattern FROM role_permissions";

    // Fetching all permissions
    List<ApiListDTO> permissions = jdbcTemplate.query(sql, (rs, rowNum) ->
            new ApiListDTO(
                    rs.getString("role"),
                    rs.getString("http_method"),
                    rs.getString("api_pattern")
            )
    );

    // Grouping permissions by role
    Map<String, List<ApiListDTO>> groupedPermissions = permissions.stream()
            .collect(Collectors.groupingBy(ApiListDTO::getRole));

    return ResponseEntity.ok(groupedPermissions);
}




}




